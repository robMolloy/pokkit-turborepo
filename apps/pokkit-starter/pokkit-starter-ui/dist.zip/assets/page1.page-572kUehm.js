import{j as e}from"./index-Dnx5E3nc.js";const a=()=>e("div",{children:e("h1",{children:"Page 1"})});export{a as default};

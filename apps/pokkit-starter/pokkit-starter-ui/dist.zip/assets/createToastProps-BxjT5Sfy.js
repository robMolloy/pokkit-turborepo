import{j as p}from"./index-Dnx5E3nc.js";const e=s=>{const[t,...r]=s;return[t,{description:r==null?void 0:r.map((o,c)=>p("p",{children:o},c))}]};export{e as c};
